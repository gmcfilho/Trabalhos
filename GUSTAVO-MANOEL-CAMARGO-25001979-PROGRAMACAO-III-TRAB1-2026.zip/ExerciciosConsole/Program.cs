using System;
using ExerciciosConsole.Exercicios;

namespace ExerciciosConsole
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int opcao = -1;

            while (opcao != 0)
            {
                Console.Clear();
                Console.WriteLine("=================================");
                Console.WriteLine("        MENU DE EXERCICIOS      ");
                Console.WriteLine("=================================");
                Console.WriteLine("1 - Calculadora");
                Console.WriteLine("2 - Contar vogais");
                Console.WriteLine("3 - Imprimir vogais");
                Console.WriteLine("4 - Imprimir consoantes");
                Console.WriteLine("5 - Faixa etaria");
                Console.WriteLine("6 - Cadastro de Livro");
                Console.WriteLine("7 - Cadastro de Aluno");
                Console.WriteLine("0 - Sair");
                Console.WriteLine("=================================");
                Console.Write("Escolha uma opcao: ");

                try
                {
                    opcao = Convert.ToInt32(Console.ReadLine());
                }
                catch
                {
                    opcao = -1;
                }

                switch (opcao)
                {
                    case 1:
                        Calculadora exercicio1 = new Calculadora();
                        exercicio1.Executar();
                        break;

                    case 2:
                        ContadorVogais exercicio2 = new ContadorVogais();
                        exercicio2.Executar();
                        break;

                    case 3:
                        ImpressorVogais exercicio3 = new ImpressorVogais();
                        exercicio3.Executar();
                        break;

                    case 4:
                        ImpressorConsoantes exercicio4 = new ImpressorConsoantes();
                        exercicio4.Executar();
                        break;

                    case 5:
                        FaixaEtaria exercicio5 = new FaixaEtaria();
                        exercicio5.Executar();
                        break;

                    case 6:
                        Livro.Executar();
                        break;

                    case 7:
                        Aluno.Executar();
                        break;

                    case 0:
                        Console.WriteLine("Ate mais!");
                        break;

                    default:
                        Console.WriteLine("Opcao invalida, tenta de novo.");
                        Console.ReadKey();
                        break;
                }
            }
        }
    }
}
