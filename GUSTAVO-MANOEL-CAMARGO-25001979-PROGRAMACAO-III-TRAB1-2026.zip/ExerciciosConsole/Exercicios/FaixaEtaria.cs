using System;

namespace ExerciciosConsole.Exercicios
{
    // Exercicio 5 - descobre a faixa etaria pela idade
    public class FaixaEtaria
    {
        public void Executar()
        {
            Console.Clear();
            Console.WriteLine("--- Faixa Etaria ---");

            Console.Write("Digite a idade: ");
            int idade = Convert.ToInt32(Console.ReadLine());

            if (idade < 0)
            {
                Console.WriteLine("Idade invalida.");
            }
            else if (idade <= 19)
            {
                Console.WriteLine("Jovem");
            }
            else if (idade <= 59)
            {
                Console.WriteLine("Adulto");
            }
            else
            {
                Console.WriteLine("Idoso");
            }

            Console.WriteLine();
            Console.WriteLine("Aperte uma tecla pra voltar...");
            Console.ReadKey();
        }
    }
}
