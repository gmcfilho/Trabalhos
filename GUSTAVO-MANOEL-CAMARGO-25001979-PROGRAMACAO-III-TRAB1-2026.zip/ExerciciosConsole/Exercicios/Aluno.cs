using System;

namespace ExerciciosConsole.Exercicios
{
    // Exercicio 7 - cadastro de aluno
    public class Aluno
    {
        public string Nome { get; set; }
        public string RA { get; set; }
        public double NotaProva { get; set; }
        public double NotaTrabalho { get; set; }
        public double Frequencia { get; set; }

        // prova vale 0.7 e trabalho vale 0.3
        public double Media()
        {
            return (NotaProva * 0.7) + (NotaTrabalho * 0.3);
        }

        // pode faltar no maximo 40% de 40 aulas, ou seja 16 faltas
        // isso da uma frequencia minima de 60%
        public bool Passou()
        {
            if (Media() >= 7 && Frequencia >= 60)
            {
                return true;
            }

            return false;
        }

        public static void Executar()
        {
            Console.Clear();
            Console.WriteLine("--- Cadastro de Aluno ---");

            Aluno aluno = new Aluno();

            Console.Write("Nome: ");
            aluno.Nome = Console.ReadLine();

            Console.Write("R.A.: ");
            aluno.RA = Console.ReadLine();

            Console.Write("Nota da prova (0 a 10): ");
            aluno.NotaProva = Convert.ToDouble(Console.ReadLine());

            Console.Write("Nota do trabalho (0 a 10): ");
            aluno.NotaTrabalho = Convert.ToDouble(Console.ReadLine());

            Console.Write("Frequencia (0 a 100): ");
            aluno.Frequencia = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine();
            Console.WriteLine("Nome: " + aluno.Nome);
            Console.WriteLine("R.A.: " + aluno.RA);
            Console.WriteLine("Media: " + aluno.Media());

            if (aluno.Passou())
            {
                Console.WriteLine("Situacao: Aprovado");
            }
            else
            {
                Console.WriteLine("Situacao: Reprovado");
            }

            Console.WriteLine();
            Console.WriteLine("Aperte uma tecla pra voltar...");
            Console.ReadKey();
        }
    }
}
