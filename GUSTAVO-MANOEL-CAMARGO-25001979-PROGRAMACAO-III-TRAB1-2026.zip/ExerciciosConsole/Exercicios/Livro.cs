using System;

namespace ExerciciosConsole.Exercicios
{
    // Exercicio 6 - cadastro de livro
    public class Livro
    {
        public string Titulo { get; set; }
        public string Autor { get; set; }
        public double Valor { get; set; }

        public void Imprimir()
        {
            Console.WriteLine();
            Console.WriteLine("Titulo: " + Titulo);
            Console.WriteLine("Autor: " + Autor);
            Console.WriteLine("Valor: R$ " + Valor);
        }

        public static void Executar()
        {
            Console.Clear();
            Console.WriteLine("--- Cadastro de Livro ---");

            Livro livro = new Livro();

            Console.Write("Titulo: ");
            livro.Titulo = Console.ReadLine();

            Console.Write("Autor: ");
            livro.Autor = Console.ReadLine();

            Console.Write("Valor: ");
            livro.Valor = Convert.ToDouble(Console.ReadLine());

            livro.Imprimir();

            Console.WriteLine();
            Console.WriteLine("Aperte uma tecla pra voltar...");
            Console.ReadKey();
        }
    }
}
