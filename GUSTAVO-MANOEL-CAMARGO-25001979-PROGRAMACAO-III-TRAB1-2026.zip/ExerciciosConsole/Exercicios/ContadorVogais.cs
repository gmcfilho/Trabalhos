using System;

namespace ExerciciosConsole.Exercicios
{
    // Exercicio 2 - conta quantas vogais tem na string
    public class ContadorVogais
    {
        public void Executar()
        {
            Console.Clear();
            Console.WriteLine("--- Contador de Vogais ---");

            Console.Write("Digite uma frase: ");
            string frase = Console.ReadLine();

            string vogais = "aeiouAEIOU";
            int cont = 0;

            for (int i = 0; i < frase.Length; i++)
            {
                if (vogais.IndexOf(frase[i]) >= 0)
                {
                    cont++;
                }
            }

            Console.WriteLine("Quantidade de vogais: " + cont);

            Console.WriteLine();
            Console.WriteLine("Aperte uma tecla pra voltar...");
            Console.ReadKey();
        }
    }
}
