using System;

namespace ExerciciosConsole.Exercicios
{
    // Exercicio 3 - so imprime as vogais da string
    public class ImpressorVogais
    {
        public void Executar()
        {
            Console.Clear();
            Console.WriteLine("--- Imprimir Vogais ---");

            Console.Write("Digite uma frase: ");
            string frase = Console.ReadLine();

            string vogais = "aeiouAEIOU";
            string resultado = "";

            for (int i = 0; i < frase.Length; i++)
            {
                char letra = frase[i];
                if (vogais.IndexOf(letra) >= 0)
                {
                    resultado += letra;
                }
            }

            Console.WriteLine("Vogais: " + resultado);

            Console.WriteLine();
            Console.WriteLine("Aperte uma tecla pra voltar...");
            Console.ReadKey();
        }
    }
}
