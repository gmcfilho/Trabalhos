using System;

namespace ExerciciosConsole.Exercicios
{
    // Exercicio 1 - calculadora basica
    public class Calculadora
    {
        public void Executar()
        {
            Console.Clear();
            Console.WriteLine("--- Calculadora ---");

            Console.Write("Digite o primeiro numero: ");
            double num1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Digite o segundo numero: ");
            double num2 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine();
            Console.WriteLine("1 - Soma");
            Console.WriteLine("2 - Subtracao");
            Console.WriteLine("3 - Multiplicacao");
            Console.WriteLine("4 - Divisao");
            Console.WriteLine("5 - Resto da divisao");
            Console.Write("Escolha a operacao: ");
            int op = Convert.ToInt32(Console.ReadLine());

            double resultado = 0;
            bool deuCerto = true;

            switch (op)
            {
                case 1:
                    resultado = num1 + num2;
                    break;
                case 2:
                    resultado = num1 - num2;
                    break;
                case 3:
                    resultado = num1 * num2;
                    break;
                case 4:
                    if (num2 == 0)
                    {
                        Console.WriteLine("Nao da pra dividir por zero!");
                        deuCerto = false;
                    }
                    else
                    {
                        resultado = num1 / num2;
                    }
                    break;
                case 5:
                    if (num2 == 0)
                    {
                        Console.WriteLine("Nao da pra tirar resto dividindo por zero!");
                        deuCerto = false;
                    }
                    else
                    {
                        resultado = num1 % num2;
                    }
                    break;
                default:
                    Console.WriteLine("Operacao invalida");
                    deuCerto = false;
                    break;
            }

            if (deuCerto)
            {
                Console.WriteLine("Resultado: " + resultado);
            }

            Console.WriteLine();
            Console.WriteLine("Aperte uma tecla pra voltar...");
            Console.ReadKey();
        }
    }
}
