using System;

namespace ExerciciosConsole.Exercicios
{
    // Exercicio 4 - so imprime as consoantes da string
    public class ImpressorConsoantes
    {
        public void Executar()
        {
            Console.Clear();
            Console.WriteLine("--- Imprimir Consoantes ---");

            Console.Write("Digite uma frase: ");
            string frase = Console.ReadLine();

            string vogais = "aeiouAEIOU";
            string resultado = "";

            for (int i = 0; i < frase.Length; i++)
            {
                char letra = frase[i];

                // pula espaco, numero e pontuacao, so quero letra que nao seja vogal
                if (char.IsLetter(letra) && vogais.IndexOf(letra) < 0)
                {
                    resultado += letra;
                }
            }

            Console.WriteLine("Consoantes: " + resultado);

            Console.WriteLine();
            Console.WriteLine("Aperte uma tecla pra voltar...");
            Console.ReadKey();
        }
    }
}
